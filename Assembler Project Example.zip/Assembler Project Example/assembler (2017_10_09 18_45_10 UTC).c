
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "assembler.h"
#include "code_manager.h"
#include "data_manager.h"
#include "symbols.h"


int assemble_file (obj_file_struct *file_record, entry **entry_table, external_symbol **extern_table, opcode opcode_table[NUM_OF_OPCODES], assembly_register register_table[NUM_OF_REGISTERS])
{
  /**********************************************************************************************************************/
  /*                                                data                                                          */
  /**********************************************************************************************************************/
  unsigned int line_counter = 0;
  file_record -> IC = 0;
  file_record -> DC = 0;
  static char current_input_line[MAX_LINE_LENGTH];

  unsigned char has_symbol = NO; /*flag */
  unsigned char input_too_long = NO; /* flag if current input line length overflows from maximum allowed */
  unsigned char successful_update = NO;
  unsigned int has_error = NO;  /* error flag for file*/

  int i,j,k = 0; /* index */

  char *util_ptr = NULL;
  symbol *symbol_table = NULL;
  symbol *symbol_ptr = NULL;
  *entry_table = NULL;
  *extern_table = NULL;
  entry *entry_ptr = NULL;
  direct_address_symbol *symbols_for_replacement_table = NULL;
  direct_address_symbol *direct_address_symbol_ptr = NULL;
  distance_addressing_symbol *symbols_for_distance_check_table = NULL;
  distance_addressing_symbol *distance_addressing_symbol_ptr = NULL;

  static code_struct code_bit_structure;
  static address_method_record address_method;
  static enum addressing_method source_method;
  static enum addressing_method target_method;
  static char current_input_token [100];
  static int data_arguments[MAX_AMOUNT_OF_ARGS];
  static char string_arguments[MAX_STRING_LENGTH];
  instrcution_struct code_arguments[MAX_CODE_ARGS];
  static char instruction_group;

  static char binary_machine_instruction [BITS_IN_REGISTER];
  char symbol_name[SYMBOL_MAX_LENGTH+1];
  static unsigned int label_length;
  static int amount_of_args;
  char hex_num[4];
  unsigned int address;

  /**********************************************************************************************************************/
  /*                                                 First Scan                                                         */
  /**********************************************************************************************************************/
  while(fgets(current_input_line, (MAX_LINE_LENGTH+1), file_record -> file_ptr))
  {
    line_counter++; /* update line counter */
    if (strlen(current_input_line) == MAX_LINE_LENGTH)
    {
      fprintf(stderr,"Warning: Line %d: input line too long. Only first %d characters would be processed!\n", line_counter, MAX_LINE_LENGTH);
      input_too_long = YES;
    }
    else
      input_too_long = NO;

    current_input_line[MAX_LINE_LENGTH-1] = '\n';

    has_symbol = label_length = amount_of_args = instruction_group = 0; /* intialize variables for new line */
    code_struct_initialize(&code_bit_structure);

    if (current_input_line[0] == ';')
      continue;

    /* check if there is a potential label by searching a terminal ':' */
    if ((util_ptr = strchr(current_input_line, ':'))) /* if so, check syntax of label */
      if(!(label_length = check_symbol_syntax(current_input_line, symbol_name, register_table, opcode_table, line_counter, &has_error, &has_symbol)))
        continue; /* if func return zero, it means the label was syntacticaly invalid - continue to next input line */

    /* (2) parse the first token from input LINE  */
    strcpy (current_input_token, current_input_line);
    util_ptr = current_input_token + label_length;

    /* check if it's a empty line (spaces & tabs)*/
    if ((util_ptr = strtok(util_ptr, ":\n\t\b ")) == NULL)
    {
      if (has_symbol)
      {
        fprintf(stderr, "Error: Line %d: Label definition failure: missing context!\n", line_counter);
        has_error++;
      }
      continue;
    }

    /*****************************************************************************************************/
    /*                                           .data or .string                                        */
    /*****************************************************************************************************/
    /* check if this is a pseudo guidance line for storing data */
    if ((strcmp(util_ptr, ".data") == 0) || (strcmp(util_ptr, ".string") == 0))
    {
      if (has_symbol)
      { /* check if it already exists at the symbol table */
        if ((symbol_ptr = check_symbol_existence(symbol_table, symbol_name)))
        {
          fprintf(stderr, "Error: Line %d: Symbol \"%s\" already defined on line %d!\n", line_counter, symbol_name, (*symbol_ptr).source_line);
          has_error++;
        }
        else
        {
          symbol_ptr = add_new_symbol(symbol_table, symbol_name, (*file_record).DC, relocatable, data, line_counter);
          if (symbol_ptr != NULL)
            symbol_table = symbol_ptr;
          else
          {
            fprintf(stderr, "Error: Line %d: System Failure: no free memory for saving symbol %s.\n", line_counter, symbol_name);
            has_error++;
          }
        }
      }

      if ((strcmp(util_ptr, ".data") == 0))
      {
        util_ptr = util_ptr + strlen(".data") + 1;
        get_data (util_ptr, data_arguments, &amount_of_args, line_counter, &has_error);
        if (amount_of_args > 0)
          successful_update = set_data (file_record->data_image, &file_record->DC, data_arguments, amount_of_args, line_counter, &has_error);
      }

      if ((strcmp(util_ptr, ".string") == 0))
      {
        util_ptr = util_ptr + strlen(".string") + 1;
        get_string (util_ptr, string_arguments, &amount_of_args, line_counter, &has_error);
        successful_update = set_string (file_record->data_image, &file_record->DC, string_arguments, amount_of_args, line_counter, &has_error);
      }

      if (!successful_update)
      {
        fprintf(stderr,"Error: Line %d: System failure in attempt to update data in the database!\n", line_counter);
        has_error++;
      }

      if (input_too_long) /* if input line LENGTH was more than MAX_LINE_LENGTH */
        for(i=0; fgetc(file_record->file_ptr) != '\n'; i++)
            ;   /* clear fp input buffer from the remaining characters of current line */

      continue;
    }

    /*****************************************************************************************************/
    /*                                         .extern or .entry                                        */
    /*****************************************************************************************************/
    else if ((strcmp(util_ptr, ".extern") == 0) || (strcmp(util_ptr, ".entry") == 0))
    {
      strcpy(current_input_token, util_ptr);
      util_ptr = util_ptr + strlen(current_input_token) + 1;
      while (isspace(*util_ptr)) /* skip spaces */
        util_ptr++;
      if((label_length = check_symbol_syntax(util_ptr, symbol_name, register_table, opcode_table, line_counter, &has_error, &has_symbol)))
      {
        util_ptr = util_ptr + label_length;
        /* validate the rest of the line is empty (spaces & tabs)*/
        if ((util_ptr = strtok(util_ptr, "\n\t\b ")) == NULL)
        {
          if (((strcmp(current_input_token, ".extern") == 0)))
          { /* validate the symbol declared is not already defined on symbol table */
            if (!(symbol_ptr = check_symbol_existence(symbol_table, symbol_name)))
            {
              symbol_ptr = add_new_symbol(symbol_table, symbol_name, external, external, external_context, line_counter);
              if (symbol_ptr != NULL)
              {
                symbol_table = symbol_ptr;
                continue;
              }
              else
                fprintf(stderr, "Error: Line %d: System Failure: not enough free memory on disk for saving symbol \"%s\"!\n", line_counter, symbol_name);
            }
            else
              fprintf(stderr, "Error: Line %d: Symbol \"%s\" already defined on line %d!\n", line_counter, symbol_name, (*symbol_ptr).source_line);
          }
          else /* it's a '.entry' statement */
          {
            entry_ptr = add_new_entry(*entry_table, symbol_name, line_counter);
            if (entry_ptr != NULL)
            {
              *entry_table = entry_ptr;
              continue;
            }
            else
              fprintf(stderr, "Error: Line %d: System Failure: not enough free memory on disk for saving declaration of entry symbol \"%s\"!\n", line_counter, symbol_name);
          }
        }
        else
          fprintf(stderr, "Error: Line %d: Extern & Entry Label declarations expect one argument exactly!\n", line_counter);
      }
      else
        fprintf(stderr, "Error: Line %d: Symbol name which was declared is illegal!\n", line_counter);

      /* if we have not reached the continue statement, it's defently a error */
      has_error++;
      continue;
    }
    /************************************************************************************************************/

    /* (3) chick validity of command (1st argument) */
    else if ((i = opcode_lookup(util_ptr, opcode_table)) == NOT_FOUND)
    {
      fprintf(stderr, "Error: Line %d: Command \"%s\" does not exist!\n", line_counter, util_ptr);
      has_error++;
      continue;
    }

    else
    {

      /* symbol */
      if (has_symbol)
      { /* check if it already exists at the symbol table */
        if ((symbol_ptr = check_symbol_existence(symbol_table, symbol_name)))
        {
          fprintf(stderr, "Error: Line %d: Symbol \"%s\" already defined on line %d!\n", line_counter, symbol_name, (*symbol_ptr).source_line);
          has_error++;
        }
        else
        {
          symbol_ptr = add_new_symbol(symbol_table, symbol_name, file_record->IC, relocatable, code, line_counter);
          if (symbol_ptr != NULL)
            symbol_table = symbol_ptr;
          else
          {
            fprintf(stderr, "Error: Line %d: System Failure: no free memory for saving symbol %s.\n", line_counter, symbol_name);
            has_error++;
          }
        }
      } /************************************/

      strncpy(code_bit_structure.group, opcode_table[i].instruction_group_binary, strlen(opcode_table[i].instruction_group_binary));
      strncpy(code_bit_structure.opcode, opcode_table[i].bin_value, strlen( opcode_table[i].bin_value));

      strcpy(current_input_token, util_ptr);
      util_ptr += strlen(opcode_table[i].name) + 1;

      instruction_group = opcode_table[i].instruction_group_decimal;
      get_instruction_args(util_ptr, code_arguments, &amount_of_args, opcode_table, register_table, line_counter, &has_error);

      /* check the arguments were valid by amount and syntax (in not-the amount is '-1' ) */
      if ((amount_of_args != instruction_group))
      {
        fprintf(stderr, "Error: Line %d: Illegal syntax for the arguments. Instruction \"%s\" accepts exactly %d arguments and only syntactically correct ones!\n", line_counter, current_input_token, instruction_group);
        has_error++;
        continue;
      }

      /* if arguments or legal, continue to proccess according to the instruction group (amount of args) */
      switch ((instruction_group))
      {
        case  (ZERO_ARGUMENT_GROUP):
        {
          concat_first_word_components(binary_machine_instruction, &code_bit_structure);
          successful_update = set_code(file_record->code_image, &file_record->IC, binary_machine_instruction, line_counter, &has_error);
          if (!successful_update)
          {
            fprintf(stderr, "Error: Line %d: System failure in attempt to update data in the database!\n", line_counter);
            has_error++;
          }
          continue;
        }

        case (ONE_ARGUMENT_GROUP):
        { /* check if the addressing method of the target operand is legal for this opcode */
          if (!check_legal_addressing_method(i, code_arguments[0].addressing_method_decimal, TARGET, opcode_table))
          {
            fprintf(stderr, "Error: Line %d: Illegal addressing method for target operand of instrcution %s!\n", line_counter, opcode_table[i].name);
            has_error++;
            continue;
          }
          strcpy(code_bit_structure.target_operand_addressing, code_arguments[0].addressing_method_binary);
          concat_first_word_components(binary_machine_instruction, &code_bit_structure);
          successful_update = set_code(file_record->code_image, &file_record->IC, binary_machine_instruction, line_counter, &has_error);
          if (!successful_update)
          {
            fprintf(stderr, "Error: Line %d: System failure in attempt to update data in the database!\n", line_counter);
            has_error++;
            continue;
          }

          switch ((code_arguments[0].addressing_method_decimal))
          {
            case  (IMMEDIATE):
            case (DIRECT_REGISTER):
            {
              if ((code_arguments[0].addressing_method_decimal) == DIRECT_REGISTER)
              { /* if register method this target, move bits to 5 right, and zero logic the left 5 */
               strncpy(code_arguments[0].additional_word+REGISTER_LENGTH, code_arguments[0].additional_word, REGISTER_LENGTH);
               for (k=0; k < REGISTER_LENGTH; k++)
                 code_arguments[0].additional_word[k] = '0';
              }
              successful_update = set_code(file_record->code_image, &file_record->IC, code_arguments[0].additional_word, line_counter, &has_error);
              if (!successful_update)
              {
                fprintf(stderr, "Error: Line %d: System failure in attempt to update data in the database!\n", line_counter);
                has_error++;
              }
              continue;
            }
            case (DIRECT):
            {
              direct_address_symbol_ptr = add_direct_address_symbol(symbols_for_replacement_table, code_arguments[0].operand[0], file_record->IC, line_counter);
              if (direct_address_symbol_ptr != NULL)
                symbols_for_replacement_table = direct_address_symbol_ptr;
              else
              {
                fprintf(stderr, "Error: Line %d: System Failure: not enough free memory on disk for saving symbol \"%s\" for direct addressing!\n", line_counter, symbol_name);
                has_error++;
              }
              file_record -> IC++;
              continue;
            }
            case (DESTINATION):
            {
              distance_addressing_symbol_ptr = add_distance_address_symbols(symbols_for_distance_check_table, code_arguments[0].operand[0], code_arguments[0].operand[1], file_record->IC, line_counter);
              if (distance_addressing_symbol_ptr != NULL)
                symbols_for_distance_check_table = distance_addressing_symbol_ptr;
              else
              {
                fprintf(stderr, "Error: Line %d: System Failure: not enough free memory on disk for saving symbols for distance addressing!\n", line_counter);
                has_error++;
              }
              file_record -> IC++;
              continue;
            }
          }
        }
        continue;

        case (TWO_ARGUMENT_GROUP):
        {
          /* check if the addressing method of the source operand is legal for this opcode */
          if(!(check_legal_addressing_method(i, code_arguments[SOURCE].addressing_method_decimal, SOURCE, opcode_table)))
          {
            fprintf(stderr, "Error: Line %d: Illegal addressing method for source operand of instrcution %s!\n", line_counter, opcode_table[i].name);
            has_error++;
            continue;
          }
          /* check if the addressing method of the target operand is legal for this opcode */
          if(!(check_legal_addressing_method(i, code_arguments[TARGET].addressing_method_decimal, TARGET, opcode_table)))
          {
            fprintf(stderr, "Error: Line %d: Illegal addressing method for target operand of instrcution %s!\n", line_counter, opcode_table[i].name);
            has_error++;
            continue;
          }


          strcpy(code_bit_structure.source_operand_addressing, code_arguments[SOURCE].addressing_method_binary);
          strcpy(code_bit_structure.target_operand_addressing, code_arguments[TARGET].addressing_method_binary);
          concat_first_word_components(binary_machine_instruction, &code_bit_structure);
          successful_update = set_code(file_record->code_image, &file_record->IC, binary_machine_instruction, line_counter, &has_error);
          if (!successful_update)
          {
            fprintf(stderr, "Error: Line %d: System failure in attempt to update data in the database!\n", line_counter);
            has_error++;
            continue;
          }

          /* check if both operands need to share the same additional word */
          if (code_arguments[SOURCE].addressing_method_decimal == DIRECT_REGISTER)
            if(code_arguments[TARGET].addressing_method_decimal == DIRECT_REGISTER)
            {
              strncpy(code_arguments[TARGET].additional_word, code_arguments[SOURCE].additional_word, REGISTER_LENGTH);
              successful_update = set_code(file_record->code_image, &file_record->IC, code_arguments[TARGET].additional_word, line_counter, &has_error);
              if (!successful_update)
              {
                fprintf(stderr, "Error: Line %d: System failure in attempt to update data in the database!\n", line_counter);
                has_error++;
              }
              continue;
            }

          /* if operands do not share, set each word individuadly for each operand    */
          /* loop at both operands (source & tareget and set code section accordingly */
          for (k = SOURCE; k <= TARGET; k++)
          {
            switch ((code_arguments[k].addressing_method_decimal))
            {
              case  (IMMEDIATE):
              case (DIRECT_REGISTER):
              {
                successful_update = set_code(file_record->code_image, &file_record->IC, code_arguments[k].additional_word, line_counter, &has_error);
                if (!successful_update)
                {
                  fprintf(stderr, "Error: Line %d: System failure in attempt to update data in the database!\n", line_counter);
                  has_error++;
                }
                continue;
              }
              case (DIRECT):
              {
                direct_address_symbol_ptr = add_direct_address_symbol(symbols_for_replacement_table, code_arguments[k].operand[0], file_record->IC, line_counter);
                if (direct_address_symbol_ptr != NULL)
                  symbols_for_replacement_table = direct_address_symbol_ptr;
                else
                {
                  fprintf(stderr, "Error: Line %d: System Failure: not enough free memory on disk for saving symbol \"%s\" for direct addressing!\n", line_counter, code_arguments[SOURCE].operand[0]);
                  has_error++;
                }
                file_record->IC++;
                continue;
              }
              case (DESTINATION):
              {
                distance_addressing_symbol_ptr = add_distance_address_symbols(symbols_for_distance_check_table, code_arguments[k].operand[0], code_arguments[k].operand[1], file_record->IC, line_counter);
                if (distance_addressing_symbol_ptr != NULL)
                  symbols_for_distance_check_table = distance_addressing_symbol_ptr;
                else
                {
                  fprintf(stderr, "Error: Line %d: System Failure: not enough free memory on disk for saving symbols for distance addressing!\n", line_counter);
                  has_error++;
                }
                file_record->IC++;
                continue;
              }
            } /* end of switch of addressing method for current operand */
          } continue; /* end of for loop for both operands */
        } /* end of two argument group instructions */
      } /* end of instruction group determination */
    } /* end of opcode instruction line parsing */
  } /* end of assembly source code file */

  /**************************************************/
  /* second */
  /*************/
  relocate_data_symbols_address(symbol_table, file_record->IC);
  set_missing_addresses(symbols_for_replacement_table, symbol_table, extern_table, file_record->code_image, &has_error);
  set_missing_distances(symbols_for_distance_check_table, symbol_table, file_record->code_image, &has_error);
  set_entry_addresses(*entry_table, symbol_table, &has_error);
  file_record -> errors = has_error;

  free_symbol_table(symbol_table);
  free_direct_address_symbol(symbols_for_replacement_table);
  free_distance_addressing_symbol(symbols_for_distance_check_table);

  return 0;
}

/**********************************************************************************************************************/
/*                                           set_opcode_table                                                         */
/**********************************************************************************************************************/
void set_opcode_table (opcode table[NUM_OF_OPCODES])
{
  /* constant values to be update in the table. each column of three rows form a single line in the table */
  const char names[NUM_OF_OPCODES][5] = {"mov", "cmp", "add", "sub", "not", "clr", "lea", "inc", "dec", "jmp", "bne", "red", "prn", "jsr", "rts", "stop"};
  const char values[NUM_OF_OPCODES][5] = {"0000", "0001", "0010", "0011", "0100", "0101", "0110", "0111", "1000", "1001", "1010", "1011", "1100", "1101", "1110", "1111"};
  const char instruction_group_binary[NUM_OF_OPCODES][3] = {"10", "10", "10", "10", "10", "01", "01", "01", "01", "01", "01", "01", "01", "01", "00", "00"};
  unsigned char instruction_group_decimal[NUM_OF_OPCODES] = {2, 2, 2, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 0, 0};
  int i; /* index */

  for (i=0; i < NUM_OF_OPCODES; i++)
  {
    strcpy(table[i].name, *(names+i));
    strcpy(table[i].bin_value, *(values+i));
    strcpy(table[i].instruction_group_binary, *(instruction_group_binary+i));
    table[i].instruction_group_decimal = instruction_group_decimal[i];
  }

  /* set legal addressing methods table for each opcode (source & destination) */
  strcpy(table[0].source_operand_legal_methods, "0123");
  strcpy(table[0].target_operand_legal_methods, "-1-3");
  strcpy(table[1].source_operand_legal_methods, "0123");
  strcpy(table[1].target_operand_legal_methods, "0123");
  strcpy(table[2].source_operand_legal_methods, "0123");
  strcpy(table[2].target_operand_legal_methods, "-1-3");
  strcpy(table[3].source_operand_legal_methods, "0123");
  strcpy(table[3].target_operand_legal_methods, "-1-3");
  strcpy(table[4].source_operand_legal_methods, "----");
  strcpy(table[4].target_operand_legal_methods, "-1-3");
  strcpy(table[5].source_operand_legal_methods, "----");
  strcpy(table[5].target_operand_legal_methods, "-1-3");
  strcpy(table[6].source_operand_legal_methods, "-1--");
  strcpy(table[6].target_operand_legal_methods, "-1-3");
  strcpy(table[7].source_operand_legal_methods, "----");
  strcpy(table[7].target_operand_legal_methods, "-1-3");
  strcpy(table[8].source_operand_legal_methods, "----");
  strcpy(table[8].target_operand_legal_methods, "-1-3");
  strcpy(table[9].source_operand_legal_methods, "----");
  strcpy(table[9].target_operand_legal_methods, "-123");
  strcpy(table[10].source_operand_legal_methods, "----");
  strcpy(table[10].target_operand_legal_methods, "-123");
  strcpy(table[11].source_operand_legal_methods, "----");
  strcpy(table[11].target_operand_legal_methods, "-123");
  strcpy(table[12].source_operand_legal_methods, "----");
  strcpy(table[12].target_operand_legal_methods, "0123");
  strcpy(table[13].source_operand_legal_methods, "----");
  strcpy(table[13].target_operand_legal_methods, "-1--");
  strcpy(table[14].source_operand_legal_methods, "----");
  strcpy(table[14].target_operand_legal_methods, "----");
  strcpy(table[15].source_operand_legal_methods, "----");
  strcpy(table[15].target_operand_legal_methods, "----");
}
/**********************************************************************************************************************/

/**********************************************************************************************************************/
/*                                           set_register_table                                                       */
/**********************************************************************************************************************/
void set_register_table (assembly_register table[NUM_OF_OPCODES])
{
  const char reg_ids [NUM_OF_OPCODES][3] = {"r0", "r1", "r2", "r3", "r4", "r5", "r6", "r7"};
  const char reg_values[NUM_OF_REGISTERS][6] = {"00000", "00001", "00010", "00011", "00100", "00101", "00110", "00111"};
  int i; /* index */

  for (i=0; i < NUM_OF_REGISTERS; i++)
  {
    strcpy(table[i].name, *(reg_ids+i));
    strcpy(table[i].bin_value, *(reg_values+i));
  }
}

/**********************************************************************************************************************/
/*                                               opcode_lookup                                                        */
/**********************************************************************************************************************/
int opcode_lookup (char *token, opcode opcode_table[NUM_OF_OPCODES])
{
  int i; /*index for search */

  for (i=0; i < NUM_OF_OPCODES; i++)
    if (strcmp (opcode_table[i].name, token) == 0)
      return i; /* if found - return index of the opcode in the table */
  return NOT_FOUND; /* in case not found */
}

/**********************************************************************************************************************/
/*                                               register_lookup                                                      */
/**********************************************************************************************************************/
int register_lookup (char *token, assembly_register register_table[NUM_OF_REGISTERS])
{
  int i; /*index for search */
  int reg_name_legnth = strlen(register_table[0].name);

  for (i=0; i < NUM_OF_REGISTERS; i++)
    if (strncmp (register_table[i].name, token, reg_name_legnth) == 0)
      return i; /* if found - return index of the register in the table */
  return NOT_FOUND; /* in case not found */
}

/***************************************************************************************************************/
/* decimal_to_binary: this function accepts a signed integer in decimal representation and an array to return  */
/* the given number as a character string in binary representation.The array must be big enough.The converison */
/* is done in the 2's complements method - negetive num msb is '1' and positive '0'. Instead of "flip-floping" */
/* bits and adding '1' for negetive values, because the representation used here is of a character string, an  */
/* alternative method for negetive values has been used here: adding 2^bits_num to the negetive value and      */
/* converting the result, that's equivalent to [(~(abs((double)(decimal_num))))+1].                            */
/* NOTE: Inorder to be portable, this function computes the num of bits at run_time using the sizeof operator. */
/* If any adjustments are needed for the num of bits,it should be done by the calling routine / proccess.      */
/***************************************************************************************************************/
char * convert_decimal_to_binary(signed int decimal_num, char *binary_num)
{
    const unsigned char BASE = 2; /* base for conversion. this func conerts to base 2 (binary). */
    unsigned int bits_in_num = BITS_IN_BYTE * sizeof(signed int); /* total bit amount */
    unsigned char remainder = 0; /* util remainder variable for computing */
    unsigned int i; /*index for binary representation chararacter array */
    signed int mask = 1; /* util lsb for masking powers of 2 - 2,4,8,16, etc... */
    char sign = '+'; /* positive\negetive sign indicator. default is set for positive. */

    if (decimal_num < 0) /* check if negetive */
    { /* for negetive values - increment them by pow(2, bits_in_num) */
      sign = '-'; /* update sign indicator minus */
      mask = mask << (bits_in_num-1); /* no space for shifting all way through because it will overflow to zero) */
      decimal_num += mask; /* increment num with mask value which is [100...00]. */
    }

    binary_num[bits_in_num] = '\0'; /* set the last array cell as a terminal sentinel */

    /* start from end of array and descend in order to have it in right order */
    i = bits_in_num;
    while (i > 0)
    {
        remainder = decimal_num % BASE; /* save the remainder */
        binary_num[--i] = remainder + '0'; /* convert it to ascii and pass it to array */
        decimal_num /= BASE; /* cut the least significant digit */
    }

    if (sign == '-')
      binary_num[i] = '1'; /* if negetive - set the first array cell (msb) to '1' for 2's complement representation.*/

    return binary_num; /*return pointer to the array holding the binary representation */
}

/**********************************************************************************************************/
/*                                         check_num                                                      */
/* this function accepts number given from input in a character string representation, and checks if it's */
/* a legal integer number. it returns 1 is it's legal and 0 if it is not legal or if the reference is NULL*/
/**********************************************************************************************************/
int check_num (char* num)
{
    int is_num = NO; /* initialize boolean flag */

    if (num == NULL) /* validation check for prevention run time errors in case of invalid pointer from caller */
        return is_num; /* zero (flag is off) */

    if((atoi(num) < INT_MIN) || (atoi(num) > INT_MAX))
         fprintf(stderr, "Warning number %d has exceded the int limit\n", atoi(num));

    /* if not null, check first charachter */
    if (isdigit(*num) || ((*num) == '+') || ((*num) == '-'))
    {
        /* skip sign if needed */
        if (((*num) == '+') || ((*num) == '-'))
            num++;
        /* validate that each character is a digit */
        while ((*num != '\0') && isdigit(*num))
            num++;

        /* incase we got so far (end of string), turn on flag */
        if ((*num) == '\0' || (*num) == '\n')
           is_num = YES;
    }
    return is_num; /* return flag result to caller according to the legality of num */
}
/*********************************************************************************************************/


/**********************************************************************************************************/
/*                                       check_legal_addressing_method                                     */
/* this function accepts an opcode index and an actual address method that was given as an istruction on  */
/* the assemly source code on the source/target operand. The function checks if the given method is legal */
/* for this opcode and this operand and returns 1 if yes, and 0 if not.                                   */
/* inorder to serve both source and target operands, a third paramter should be send as a parameter to    */
/* distinguish by the two, and the opcode table with consists the legal methods for each opcode.          */
/**********************************************************************************************************/
int check_legal_addressing_method (int op_index, int actual_method, char operand_role, opcode *op_table)
{
  actual_method += '0';
  char *util_ptr = NULL;
  /* check if the actual method is one of the allowed methods in the opcode table apropiate field (source/target) */
  if (operand_role == SOURCE)
    util_ptr = strchr(op_table[op_index].source_operand_legal_methods,  (char)actual_method);
  else if (operand_role == TARGET)
    util_ptr = strchr(op_table[op_index].target_operand_legal_methods, (char)actual_method);
  if (util_ptr) /* if actual method found in permitted list */
    return YES;
  else /* actual method not found */
    return NO;
}
/************************************************************************************************************/

/***************************************************************************************************************/
/* convert_binary_to_decimal */
/***************************************************************************************************************/

unsigned int convert_binary_to_decimal(const char * binary_num)
{

  int num_length = strlen(binary_num);
  int i = num_length-1;
  int power = 0;
  int decimal_num;
  int atoi_mask = '0';

  decimal_num = (binary_num[i] - atoi_mask) * (int)pow(BINARY_BASE, power);
  power++;

  while (--i >= 0)
  {
    decimal_num += (binary_num[i] - atoi_mask) * (int)pow(BINARY_BASE, power);
    power++;
  }
  return decimal_num;
}
/**************************************************************************************************/



