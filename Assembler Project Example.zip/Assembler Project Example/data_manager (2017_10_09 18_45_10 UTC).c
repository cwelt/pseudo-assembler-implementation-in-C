/*
 * data_manager.c
 */

#include "assembler.h"
#include "data_manager.h"


/***********************************************************************************************************/
/*                                          get_data                                                       */
/* This function is used to validate ".data" arguments before updating them in the data image. It recevies */
/* an input line of characters, and validates it contains a list of legal intergers separated by commas.   */
/* If legal - the function converts the numbers from string characters into integers and saves them in a   */
/* target array that is past by the calling routine, and returns the amount of numbers saved in the list.  */
/* if not legal, the function returns 0.                                                                   */
/***********************************************************************************************************/
int get_data (char* line, int converted_num_list[], int *amount_of_args, unsigned int line_num, unsigned int *error_flag)
{
    unsigned char has_unsatisfied_comma; /* indicator if there is a comma following current token or not */
    char current_token[MAX_LINE_LENGTH];
    unsigned int token_length; /* length of current data token */
    char *util_ptr = line; /* util pointer for parsing the data */
    int scan_success = 0; /* scanf indicator of success or failure */
    *amount_of_args = 0; /* initialize amount of numeric arguments in input line */

    if (line != NULL) /* validation check for preventing run time errors in case of invalid pointer from caller */
    {
      while(isspace(*util_ptr))
        util_ptr++;
      current_token[0] = '\0';
      while (((scan_success = sscanf(util_ptr, "%[^\b\t ,]", current_token)) > 0))
      {
        has_unsatisfied_comma = 0;
        /* (1) validate the token is a legal interger - if so save it */
        if (check_num(current_token)) /* if legal - convert to int and save in array */
          converted_num_list[(*amount_of_args)++] = atoi(current_token);
        else
        { /* if not legal, print error and return apropiate signal */
          fprintf(stderr, "Error: Line %d: \".data\" encounterd an illegal interger: \"%s\"!\n", line_num, current_token);
          (*error_flag)++;
          *amount_of_args = 0;
          return *amount_of_args;
        }

        /* (2) advance to next token to see if it's a comma */
        token_length = strlen(current_token);
        util_ptr = util_ptr + token_length;
        while(isspace(*util_ptr)) /* skip spaces */
          util_ptr++;
        if (*util_ptr == ',')
        {
          has_unsatisfied_comma = 1;
          util_ptr++;
          while(isspace(*util_ptr))
            util_ptr++;
          continue;
        }

        else if((strcmp(util_ptr, "") == 0))
          return *amount_of_args;

        else if (*util_ptr != '\n' && *util_ptr != '\0')
        {
          fprintf(stderr, "Error: Line %d: \".data\" missing comma delimeter after number %d!\n", line_num, converted_num_list[(*amount_of_args)-1]);
          (*error_flag)++;
          *amount_of_args = 0;
          return *amount_of_args;
        }
      }

      if(*amount_of_args == 0)
      {
        fprintf(stderr, "Error: Line %d: \".data\" command received no number arguments!\n", line_num);
        (*error_flag)++;
        *amount_of_args = 0;
        return *amount_of_args;
      }

      else if(*util_ptr == ',')
      {
        fprintf(stderr, "Error: Line %d: \".data\" syntax error: two consecutive comma delimeters with out a number in between!\n", line_num);
        (*error_flag)++;
        *amount_of_args = 0;
        return *amount_of_args;
      }

      else if((strcmp(util_ptr, "") == 0))
      {
       if(has_unsatisfied_comma)
       {
         fprintf(stderr, "Error: Line %d: \".data\" syntax error: unsatesfied comma delimeter at end of line!\n", line_num);
         (*error_flag)++;
         *amount_of_args = 0;
         return *amount_of_args;
       }
       else
         return *amount_of_args;
      }
    }
    return *amount_of_args; /* return result to caller - in case of NULL pointer or empty like the result is 0 */
}
/*********************************************************************************************************/

/**********************************************************************************************************/
/*                                              set_data                                                  */
/**********************************************************************************************************/
int set_data (char data_image[MAX_OUTPUT_DATA_LINES][BITS_IN_REGISTER+1], unsigned int *DC, int data_arguments[MAX_AMOUNT_OF_ARGS], int amount_of_args, unsigned int line_num, unsigned int *error_flag)
{
  int i;
  static char num_in_binary[BITS_IN_BYTE * sizeof(signed int)+1];
  char *util_ptr;

  for (i=0; i < amount_of_args && *DC < MAX_OUTPUT_DATA_LINES; i++)
  {
    convert_decimal_to_binary(data_arguments[i], num_in_binary); /* get the binary representation */
    util_ptr = num_in_binary + strlen(num_in_binary) - BITS_IN_REGISTER; /* skip reduant prefix by jumping to end and cuting 12 lsb*/

    if (*DC < MAX_OUTPUT_DATA_LINES) /* assure there is free memory space */
    {
      strcpy(data_image[*DC], util_ptr);
      (*DC)++;
    }
    else
    {
      fprintf(stderr, "Error: Line %d: Not enough free memory space for saving more data!\n", line_num);
      error_flag++;
      return 0;
    }
  }
  return i;
}

/***********************************************************************************************************/
/*                                          get_string                                                      */
/* This function is used to validate ".string" arguments before updating them in the data image. It recevies */
/* an input line of characters, and validates it contains a list of legal intergers separated by commas.   */
/* If legal - the function converts the numbers from string characters into integers and saves them in a   */
/* target array that is past by the calling routine, and returns the amount of numbers saved in the list.  */
/* if not legal, the function returns 0.                                                                   */
/***********************************************************************************************************/
int get_string (char* line, char *char_arguments, int *amount_of_args, unsigned int line_num, unsigned int *error_flag)
{
    char *util_ptr; /* util pointer for parsing the data */
    *amount_of_args = 0; /* initialize amount of numeric arguments in input line */

    if (line != NULL) /* validation check for preventing run time errors in case of invalid pointer from caller */
    {
      while(isspace(*line))
        line++;

      util_ptr = strchr(line, '\"');
      if(util_ptr != NULL)
      {
        if (*util_ptr != *line)
        {
          fprintf(stderr, "Error: Line %d: \'.string\' syntax error: missing double quotes (\") at beginning of string!\n", line_num);
          (*error_flag)++;
          return *amount_of_args;
        }

        util_ptr++;
        while(*util_ptr != '\"' && *util_ptr != '\n' && *util_ptr != '\0')
        {
          *char_arguments++ = *util_ptr++;
          (*amount_of_args)++;
        }

        if(*util_ptr == '\"')
        {
          *char_arguments = '\0';
          (*amount_of_args) += 1; /* increment length by 1 for '\0' terminator */
          return *amount_of_args;
        }
        else
        {
          fprintf(stderr, "Error: Line %d: \'.string\' syntax error: missing double quotes (\") at end of string!\n", line_num);
          (*error_flag)++;
          return *amount_of_args;
        }
      }
      else
      {
        fprintf(stderr, "Error: Line %d: \'.string\' syntax error: missing double quotes (\") before and after the string!\n", line_num);
        (*error_flag)++;
        return *amount_of_args;
      }
    }
    else
    {
      fprintf(stderr, "Error: Line %d: \'.string\' argument error: NULL char pointer given as argument!\n", line_num);
      (*error_flag)++;
      return *amount_of_args;
    }
}

/**********************************************************************************************************/
/*                                          set_string                                                    */
/**********************************************************************************************************/
int set_string (char data_image[MAX_OUTPUT_DATA_LINES][BITS_IN_REGISTER+1], unsigned int *DC, char char_arguments[MAX_STRING_LENGTH], int amount_of_args, unsigned int line_num, unsigned int *error_flag)
{
  int i;
  static char num_in_binary[BITS_IN_BYTE * sizeof(unsigned int)+1];
  char *util_ptr;

  for (i=0; i < amount_of_args && *DC < MAX_OUTPUT_DATA_LINES; i++)
  {
    convert_decimal_to_binary((unsigned)char_arguments[i], num_in_binary); /* get the binary representation */
    util_ptr = num_in_binary + strlen(num_in_binary) - BITS_IN_REGISTER; /* skip reduant prefix by jumping to end and cuting 12 lsb*/

    if (*DC < MAX_OUTPUT_DATA_LINES) /* assure there is free memory space */
    {
      strcpy(data_image[*DC], util_ptr);
      (*DC)++;
    }
    else
    {
      fprintf(stderr, "Error: Line %d: Not enough free memory space for saving more data!\n", line_num);
      error_flag++;
      return 0;
    }
  }
  return i;
}
/***********************************************************************************************************/


