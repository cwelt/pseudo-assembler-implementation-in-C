/*
 * symbols.h
 */
#ifndef MAMAN14_SYMBOLS_H_
#define MAMAN14_SYMBOLS_H_

#include "assembler.h"

typedef enum type_of_symbol {external, relocatable} symbol_type;  /* symbol type */
typedef enum context_of_symbol {external_context, data, code} symbol_context;

typedef struct symbol_node
{
    char name[SYMBOL_MAX_LENGTH+1];  /* name of symbol (label) */
    unsigned int address_decimal_value; /* decimal value symbol adress */
    symbol_type type; /* external or relocatable */
    symbol_context context; /* data or code */
    unsigned int source_line;
    struct symbol_node *next;
} symbol;


typedef struct entry_node
{
    char name[SYMBOL_MAX_LENGTH+1];  /* name of symbol (label) */
    unsigned int address_decimal_value; /* decimal value symbol adress */
    unsigned int source_line;
    struct entry_node *next;
} entry;

typedef struct external_node
{
    char name[SYMBOL_MAX_LENGTH+1];  /* name of symbol (label) */
    unsigned int address_decimal_value; /* decimal value symbol adress */
    struct external_node *next;
} external_symbol;



typedef struct direct_addressing_symbol
{
  char name[SYMBOL_MAX_LENGTH+1];
  unsigned int address;
  unsigned int source_line;
  direct_addressing_symbol *next;
} direct_address_symbol;


typedef struct distance_addressing_symbols
{
  char name1[SYMBOL_MAX_LENGTH+1];
  char name2[SYMBOL_MAX_LENGTH+1];
  unsigned int address;
  unsigned int source_line;
  distance_addressing_symbols *next;
} distance_addressing_symbol;


symbol * check_symbol_existence (symbol *head, char *name);
symbol * add_new_symbol (symbol *head, char *name, unsigned int decimal_address, symbol_type type, symbol_context context, unsigned int line);
entry * add_new_entry(entry *head, char *name, unsigned int line);
external_symbol * add_new_extern (external_symbol *head, char *name, unsigned int address);
direct_address_symbol * add_direct_address_symbol (direct_address_symbol *head, char *symbol_name, unsigned int address, unsigned int line);
distance_addressing_symbol *add_distance_address_symbols (distance_addressing_symbol *head, char *name1, char *name2, unsigned int address, unsigned int line);
void relocate_data_symbols_address (symbol *head, unsigned int IC);
void set_missing_addresses (direct_address_symbol *head, symbol *symbol_table, external_symbol **extern_table, char missing_address_line[][BITS_IN_REGISTER+1], unsigned int *error_flag);
void set_missing_distances (distance_addressing_symbol *head, symbol *symbol_table, char missing_distance_line[][BITS_IN_REGISTER+1], unsigned int *error_flag);
void set_entry_addresses (entry *entry_table, symbol *symbol_table, unsigned int *error_flag);
void free_symbol_table (symbol *head);
void free_entry_table (entry *head);
void free_extern_table (external_symbol *head);
void free_direct_address_symbol (direct_address_symbol *head);
void free_distance_addressing_symbol (distance_addressing_symbol *head);

#endif /* MAMAN14_SYMBOLS_H_ */
