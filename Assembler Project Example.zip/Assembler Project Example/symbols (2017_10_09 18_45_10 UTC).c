/*
 * symbols.c
 */
#include "symbols.h"
#include "assembler.h"
#include "data_manager.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/**********************************************************************************************************************/
/*                                            check_symbol_syntax                                                     */
/**********************************************************************************************************************/
int check_symbol_syntax (char* input_line, char* symbol_name, assembly_register *reg_table, opcode *op_table, unsigned int line_num, unsigned int *error_flag, unsigned char *symbol_flag)
{
  unsigned char symbol_length;
  int i;
  char *util_ptr;

  /*validate that the label starts on first column of the line */
  if(isalpha(*input_line))
  { /* calculate length of label and check if it's legal */
    util_ptr = strrchr(input_line, ':');

    /* check if this is a new symbol definition or just a extern/entry declaration */
    if (util_ptr == NULL) /* if no ':', it's a extern\entry declaration, and not a new symbol definition */
    { /* advance to end of label name in order to calculate its length */
      util_ptr = input_line;
      while (!isspace(*util_ptr) && (*util_ptr) != '\0' && (*util_ptr) != '\n' && (*util_ptr) != ',')
        util_ptr++;
    }
    symbol_length = util_ptr - input_line;
    if (symbol_length <= SYMBOL_MAX_LENGTH)
    { /* isolate label's name from the input line and save it */
      strncpy(symbol_name, input_line, symbol_length);
      *(symbol_name + symbol_length) = '\0'; /* terminate name with the null character */
      for (util_ptr = input_line; util_ptr && isalnum(*util_ptr); util_ptr++) /* check name legality */
        ;      /* scan the name till it's end and validate that each character is alpha numeric */
      if (((util_ptr - input_line) == (symbol_length))) /* check if the name scan succeded all way through; */
        if (register_lookup(symbol_name, reg_table) == NOT_FOUND) /* validate name is not a register name */
          if (opcode_lookup(symbol_name, op_table) == NOT_FOUND) /* validate name is not a opcode name */
          { /* if we got this far, then the given input line has a label */
            *symbol_flag = YES;     /* turn on indicator for current input line*/
            return symbol_length;  /* return the length of the label's name */
          }
          else
            fprintf(stderr, "  : line %d: Label name may not be a command's(opcode) name!\n", line_num);
        else
          fprintf(stderr, "Error: line %d: Label name may not be a register's name!\n", line_num);
      else
        fprintf(stderr, "Error: line %d: Label name may contain only alphabetic characters and numbers!\n", line_num);
    }
    else
      fprintf(stderr, "Error: line %d: Label name exceeded max length which is 30 characters at most.\n", line_num);
  }
  else if (*input_line == '\b' || *input_line == '\t' ||  *input_line == ' ')
    fprintf(stderr, "Error: line %d: Label must start on first column of the line!\n", line_num);
  else
    fprintf(stderr, "Error: line %d: Label name must start with an alphabetic letter!\n", line_num);

  (*error_flag)++;
  return 0;
}
/**********************************************************************************************************************/


/*********************************************************************************************************************/
/*                                             check_symbol_existence                                                */
/*********************************************************************************************************************/
/* This function receives a label name and checks if a symbol containing this name has already been registers in the */
/* symbol table. if the symbol exists at the table, the function would return a pointer to it and NULL if it isn't.  */
/*********************************************************************************************************************/
symbol *check_symbol_existence (symbol *head, char *name)
{
  symbol *util_ptr; /* utillity pointer for searching through the symbol table */
  /* scan the entire symbol list */
  for (util_ptr = head; util_ptr != NULL; util_ptr = util_ptr -> next)
  { /* check if the given label is identical to the current symbols name */
    if (strcmp (name, util_ptr -> name) == 0)
      break; /* if so, we are pointing at the desired symbol */
  }
  /* return result to caller (incase head was pointing to a null adress, the result would return null) */
  return util_ptr;
}
/*********************************************************************************************************************/



/*********************************************************************************************************************/
/*                                                 add_new_symbol                                                    */
/*********************************************************************************************************************/
symbol * add_new_symbol (symbol *head, char *name, unsigned int decimal_address, symbol_type type, symbol_context context, unsigned int line)
{
  symbol *util_ptr; /* utillity pointer  */
  util_ptr = (symbol*)calloc(1, sizeof(symbol));

  if (util_ptr != NULL)
  {
    strcpy(util_ptr -> name, name);
    util_ptr -> address_decimal_value = decimal_address;
    util_ptr -> type = type;
    util_ptr -> context = context;
    util_ptr -> source_line = line;
    util_ptr -> next = head;
    head = util_ptr;
    return head;
  }
  else
    return NULL;
}
/*********************************************************************************************************************/

/*********************************************************************************************************************/
/*                                                 add_new_entry                                                    */
/*********************************************************************************************************************/
entry * add_new_entry (entry *head, char *name, unsigned int line)
{
  entry *util_ptr; /* utillity pointer  */
  entry *new_entry;
  new_entry = (entry*)calloc(1, sizeof(entry));


  if (new_entry != NULL)
  {
    strcpy(new_entry -> name, name);
    new_entry -> source_line = line;

    util_ptr = head;
    if (util_ptr != NULL)
    {
      while ((util_ptr -> next) != NULL)
        util_ptr = util_ptr -> next;
      util_ptr -> next = new_entry;
    }
    else
    {
      new_entry -> next = head;
      head = new_entry;
    }
    return head;
  }
  else
    return NULL;
}
/*********************************************************************************************************************/


/*********************************************************************************************************************/
/*                                                 add_new_extern                                                  */
/*********************************************************************************************************************/
external_symbol * add_new_extern (external_symbol *head, char *name, unsigned int address)
{
  external_symbol *util_ptr; /* utillity pointer  */
  external_symbol *new_extern;
  new_extern = (external_symbol*)calloc(1, sizeof(external_symbol));

  if (new_extern != NULL)
  {
    strcpy(new_extern -> name, name);
    new_extern -> address_decimal_value = address + BASE_START;

    new_extern -> next = head;
    head = new_extern;
    return head;
  }
  else
    return NULL;
}
/*********************************************************************************************************************/





/*********************************************************************************************************************/
/*                                       add_direct_address_symbol                                                    */
/*********************************************************************************************************************/

direct_address_symbol * add_direct_address_symbol (direct_address_symbol *head, char *symbol_name, unsigned int address, unsigned int line)
{
  direct_address_symbol *util_ptr; /* utillity pointer  */
  util_ptr = (direct_address_symbol*)calloc(1, sizeof(direct_address_symbol));

  if (util_ptr != NULL)
  {
    strcpy(util_ptr -> name, symbol_name);
    util_ptr -> address = address;
    util_ptr -> source_line = line;
    util_ptr -> next = head;
    head = util_ptr;
    return head;
  }
  else
    return NULL;
}
/***********************************************************************************************************************/

/*********************************************************************************************************************/
/*                                             add_distance_address_symbols                                        */
/*********************************************************************************************************************/
distance_addressing_symbol *add_distance_address_symbols (distance_addressing_symbol *head, char *name1, char *name2, unsigned int address, unsigned int line)
{
  distance_addressing_symbol *util_ptr; /* utillity pointer  */
  util_ptr = (distance_addressing_symbol*)calloc(1, sizeof(distance_addressing_symbol));

  if (util_ptr != NULL)
  {
    strcpy(util_ptr -> name1, name1);
    strcpy(util_ptr -> name2, name2);
    util_ptr -> address = address;
    util_ptr -> source_line = line;
    util_ptr -> next = head;
    head = util_ptr;
    return head;
  }
  else
    return NULL;
}
/***********************************************************************************************************************/


/*********************************************************************************************************************/
/*                                       update_data_symbols_address                                                 */
/*********************************************************************************************************************/
/* This function receives an IC (instruction counter) and a symbol table, and updated each symbol which is marked as */
/* as data, to it's relocatable address, after adding the offset of the amount of machine instruction output lines.  */
/*********************************************************************************************************************/
void relocate_data_symbols_address (symbol *head, unsigned int IC)
{
  symbol *util_ptr; /* utillity pointer for searching through the symbol table */
  /* scan the entire symbol list */
  for (util_ptr = head; util_ptr != NULL; util_ptr = util_ptr -> next)
  { /* check if the given label is marked as with data address */
    if (util_ptr -> context == data)
      util_ptr -> address_decimal_value += IC+1; /* if so, relcoate it's address by offset of IC */
  }
}
/*************************************************************************************************************/


/*********************************************************************************************************************/
/*                                  set_missing_addresses                                               */
/*********************************************************************************************************************/
/* this function sets the addressed in code section of the direct addressing method symbols, whice we did not know at*/
/* first. */
/********************************************************************************************************************/
void set_missing_addresses (direct_address_symbol *head, symbol *symbol_table, external_symbol **extern_table, char missing_address_line[][BITS_IN_REGISTER+1], unsigned int *error_flag)
{
  direct_address_symbol *direct_ptr = head; /* utillity pointer  */
  symbol *symbol_ptr;
  external_symbol *external_ptr;
  char const relocatable_postfix[] = "10";
  char const external_postfix[] = "01";
  char temp_binary_address[MAX_LINE_LENGTH];
  char *char_ptr;

  for (; direct_ptr != NULL; direct_ptr = direct_ptr -> next)
  {
    symbol_ptr = check_symbol_existence(symbol_table, direct_ptr -> name);

    if (symbol_ptr == NULL)
    {
      fprintf(stderr, "Error: Line %d: Symbol \"%s\" is not defined!\n", direct_ptr -> source_line, direct_ptr -> name);
      (*error_flag)++;
      continue;
    }

    convert_decimal_to_binary(symbol_ptr -> address_decimal_value, temp_binary_address);
    char_ptr = temp_binary_address + strlen(temp_binary_address) - BITS_IN_ADDITIONAL_WORD;
    if (symbol_ptr -> type == external)
    {
      strcat(char_ptr, external_postfix);
      /* if it's external save it's location at external's file */
      external_ptr = add_new_extern(*extern_table, direct_ptr -> name, direct_ptr -> address);
      if (external_ptr != NULL)
        *extern_table = external_ptr;
      else
      {
        fprintf(stderr, "Error: Not enough memory on disk to save external symbol \"%s\"!\n", direct_ptr -> name);
        (*error_flag)++;
      }
    }
    else
      strcat(char_ptr, relocatable_postfix);
    strncpy(missing_address_line[direct_ptr->address], char_ptr, BITS_IN_REGISTER);
  }
}
/***********************************************************************************************************************/


/*********************************************************************************************************************/
/*                                  set_missing_distances                                               */
/*********************************************************************************************************************/
/********************************************************************************************************************/
void set_missing_distances (distance_addressing_symbol *head, symbol *symbol_table, char missing_distance_line[][BITS_IN_REGISTER+1], unsigned int *error_flag)
{
  distance_addressing_symbol *distance_ptr = head; /* utillity pointer  */
  symbol *symbol_ptr1;
  symbol *symbol_ptr2;
  int distance1, distance2, distance3;
  int max_distance;
  char temp_binary_address[MAX_LINE_LENGTH];
  char *char_ptr;
  const char absolute[] = "00";

  for (; distance_ptr != NULL; distance_ptr = distance_ptr -> next)
  {
    symbol_ptr1 = check_symbol_existence(symbol_table, distance_ptr -> name1);
    symbol_ptr2 = check_symbol_existence(symbol_table, distance_ptr -> name2);

    if (symbol_ptr1 == NULL)
    {
      fprintf(stderr, "Error: Line %d: Symbol \"%s\" is not defined!\n", distance_ptr -> source_line, distance_ptr -> name1);
      (*error_flag)++;
      continue;
    }
    if (symbol_ptr2 == NULL)
    {
      fprintf(stderr, "Error: Line %d: Symbol \"%s\" is not defined!\n", distance_ptr -> source_line, distance_ptr -> name2);
      (*error_flag)++;
      continue;
    }

    distance1 = (symbol_ptr1 -> address_decimal_value) - (symbol_ptr2 -> address_decimal_value);
    distance2 = (distance_ptr -> address) - (symbol_ptr1 -> address_decimal_value);
    distance3 = (distance_ptr -> address) - (symbol_ptr2 -> address_decimal_value);
    distance1 = abs(distance1);
    distance2 = abs(distance2);
    distance3 = abs(distance3);

    max_distance = ((distance1 >= distance2) ? distance1 : distance2);
    max_distance = ((max_distance >= distance3) ? max_distance : distance3);

    convert_decimal_to_binary(max_distance, temp_binary_address);
    char_ptr = temp_binary_address + strlen(temp_binary_address) - BITS_IN_ADDITIONAL_WORD;
    strcat(char_ptr, absolute);
    strncpy(missing_distance_line[distance_ptr->address], char_ptr, BITS_IN_REGISTER);
  }
}
/**********************************************************/

/*************************************************************************/
void set_entry_addresses (entry *entry_table, symbol *symbol_table, unsigned int *error_flag)
{
  entry *entry_ptr;
  symbol *symbol_ptr;
  for (entry_ptr = entry_table; entry_ptr != NULL; entry_ptr = entry_ptr -> next)
  {
    for(symbol_ptr = symbol_table; symbol_ptr != NULL; symbol_ptr = symbol_ptr -> next)
      if((strcmp(entry_ptr -> name, symbol_ptr -> name) == 0))
      {
        entry_ptr -> address_decimal_value = BASE_START + symbol_ptr -> address_decimal_value;
        break;
      }
    if (symbol_ptr == NULL) /* entry symbol not found on symbol table */
    {
      fprintf(stderr, "Error: Line %d: Entry symbol %s does not exist in the symbol table!\n", entry_ptr->source_line, entry_ptr->name);
      (*error_flag)++;
    }
  }
}
/*******************************************************************************************/




/*********************************************************************************************************/
/*                                          free_symbol_table                                            */
/*********************************************************************************************************/
/* This Function releases reserved dynamic memory for the symbol table  back to operating system         */
/*********************************************************************************************************/
void free_symbol_table (symbol *head)
{
  symbol *current_node_ptr; /* pointer of current node to be freed */
  symbol *ptr_at_front; /* util pointer to be up front to hold the remaining of list */

  /* (1) point to head of table */
  current_node_ptr = head;
  /* (2) scan the table as lone there are more records left in it to be freed */
  while (current_node_ptr != NULL)
  { /* (3) make back up pointer to point to next record in table, for not getting lost trapped memory */
    ptr_at_front = current_node_ptr -> next;
    free(current_node_ptr); /* (4) free memory of current record */
    current_node_ptr = ptr_at_front; /* (5) advance to backup next record on front */
  }
}
/*********************************************************************************************************/


/*********************************************************************************************************/
/*                                          free_entry_table                                             */
/*********************************************************************************************************/
/* This Function releases reserved dynamic memory for the entry table  back to operating system.         */
/*********************************************************************************************************/
void free_entry_table (entry *head)
{
  entry *current_node_ptr; /* pointer of current node to be freed */
  entry *ptr_at_front; /* util pointer to be up front to hold the remaining of list */

  /* (1) point to head of table */
  current_node_ptr = head;
  /* (2) scan the table as lone there are more records left in it to be freed */
  while (current_node_ptr != NULL)
  { /* (3) make back up pointer to point to next record in table, for not getting lost trapped memory */
    ptr_at_front = current_node_ptr -> next;
    free(current_node_ptr); /* (4) free memory of current record */
    current_node_ptr = ptr_at_front; /* (5) advance to backup next record on front */
  }
}
/*********************************************************************************************************/


/*********************************************************************************************************/
/*                                          free_extern_table                                            */
/*********************************************************************************************************/
/* This Function releases reserved dynamic memory for the extern table  back to operating system.        */
/*********************************************************************************************************/
void free_extern_table (external_symbol *head)
{
  external_symbol *current_node_ptr; /* pointer of current node to be freed */
  external_symbol *ptr_at_front; /* util pointer to be up front to hold the remaining of list */

  /* (1) point to head of table */
  current_node_ptr = head;
  /* (2) scan the table as lone there are more records left in it to be freed */
  while (current_node_ptr != NULL)
  { /* (3) make back up pointer to point to next record in table, for not getting lost trapped memory */
    ptr_at_front = current_node_ptr -> next;
    free(current_node_ptr); /* (4) free memory of current record */
    current_node_ptr = ptr_at_front; /* (5) advance to backup next record on front */
  }
}
/*********************************************************************************************************/

/*********************************************************************************************************/
/*                                      free_direct_address_symbol                                       */
/*********************************************************************************************************/
/* This Function releases reserved dynamic memory for the table of direct addressing used symbols back to*/
/* the operating system.                                                                                 */
/*********************************************************************************************************/
void free_direct_address_symbol (direct_address_symbol *head)
{
  direct_address_symbol *current_node_ptr; /* pointer of current node to be freed */
  direct_address_symbol *ptr_at_front; /* util pointer to be up front to hold the remaining of list */

  /* (1) point to head of table */
  current_node_ptr = head;
  /* (2) scan the table as lone there are more records left in it to be freed */
  while (current_node_ptr != NULL)
  { /* (3) make back up pointer to point to next record in table, for not getting lost trapped memory */
    ptr_at_front = current_node_ptr -> next;
    free(current_node_ptr); /* (4) free memory of current record */
    current_node_ptr = ptr_at_front; /* (5) advance to backup next record on front */
  }
}
/*********************************************************************************************************/

/*********************************************************************************************************/
/*                                     free_distance_addressing_symbol                                   */
/*********************************************************************************************************/
/* This Function releases reserved dynamic memory for the table of distance addressing used symbols back */
/* to the operating system.                                                                              */
/*********************************************************************************************************/
void free_distance_addressing_symbol (distance_addressing_symbol *head)
{
  distance_addressing_symbol *current_node_ptr; /* pointer of current node to be freed */
  distance_addressing_symbol *ptr_at_front; /* util pointer to be up front to hold the remaining of list */

  /* (1) point to head of table */
  current_node_ptr = head;
  /* (2) scan the table as lone there are more records left in it to be freed */
  while (current_node_ptr != NULL)
  { /* (3) make back up pointer to point to next record in table, for not getting lost trapped memory */
    ptr_at_front = current_node_ptr -> next;
    free(current_node_ptr); /* (4) free memory of current record */
    current_node_ptr = ptr_at_front; /* (5) advance to backup next record on front */
  }
}
/*********************************************************************************************************/
