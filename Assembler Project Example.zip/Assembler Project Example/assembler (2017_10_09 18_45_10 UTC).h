
#include "symbols.h"

#ifndef MAMAN14_ASSEMBLER_H_
#define MAMAN14_ASSEMBLER_H_

#define NUM_OF_OPCODES 16
#define NUM_OF_REGISTERS 8
#define NUM_OF_ADDRESSING_METHODS 4
#define BITS_IN_REGISTER 12
#define BITS_IN_BYTE 8
#define MAX_LINE_LENGTH 80
#define MAX_INPUT_LINES 100
#define MAX_OUTPUT_CODE_LINES 500
#define MAX_OUTPUT_DATA_LINES 500
#define BITS_IN_ADDITIONAL_WORD 10
#define REGISTER_LENGTH 5
#define SYMBOL_MAX_LENGTH 30
#define MAX_CODE_ARGS 2
#define MAX_LEGAL_METHODS 4
#define ZERO_ARGUMENT_GROUP 0
#define ONE_ARGUMENT_GROUP 1
#define TWO_ARGUMENT_GROUP 2
#define IMMEDIATE 0
#define DIRECT 1
#define DESTINATION 2
#define DIRECT_REGISTER 3
#define SOURCE 0
#define TARGET 1
#define BASE_START 100
#define BINARY_BASE 2
#define OBJECT_BASE 16


#define YES 1 /* flag activation indicator */
#define NO 0 /* flag de-activation indicator */
#define NOT_FOUND -1

typedef struct object_file_structure
{
  FILE *file_ptr;
  char name[FILENAME_MAX];
  unsigned int IC;
  unsigned int DC;
  char code_image[MAX_OUTPUT_CODE_LINES][BITS_IN_REGISTER+1];
  char data_image[MAX_OUTPUT_CODE_LINES][BITS_IN_REGISTER+1];
  unsigned int errors;
} obj_file_struct;

/* opcode info record defention */
typedef struct opcode_node
{
    char name[5]; /* name of operation */
    char bin_value[5]; /* binary value of the opcode name */
    char instruction_group_binary[3]; /* group type of the instruction for determining num of args and format*/
    unsigned char instruction_group_decimal;
    char source_operand_legal_methods[MAX_LEGAL_METHODS+1];
    char target_operand_legal_methods[MAX_LEGAL_METHODS+1];
} opcode;

/* register info record defention */
typedef struct register_node
{
    char name[3]; /* name of regsiter  */
    char bin_value[6]; /* binary value of the register name */
} assembly_register; /*register name and value */


typedef struct hexadecimal_digit
{
  char binary_num[4];
  char hex_digit;
} hex_digit;



void set_register_table (assembly_register table[NUM_OF_REGISTERS]);
void set_opcode_table (opcode table[NUM_OF_OPCODES]);

int opcode_lookup (char *token, opcode opcode_table[NUM_OF_OPCODES]);
int register_lookup (char *token, assembly_register register_table[NUM_OF_REGISTERS]);
int check_symbol_syntax (char* input_line, char* symbol_name, assembly_register *reg_table, opcode *op_table, unsigned int line_num, unsigned int *error_flag, unsigned char *symbol_flag);
char *convert_decimal_to_binary(signed int decimal_num, char * binary_num);
unsigned int convert_binary_to_decimal(const char * binary_num);
int check_legal_addressing_method (int op_index, int actual_method, char operand_role, opcode *op_table);

#endif /* MAMAN14_ASSEMBLER_H_ */
