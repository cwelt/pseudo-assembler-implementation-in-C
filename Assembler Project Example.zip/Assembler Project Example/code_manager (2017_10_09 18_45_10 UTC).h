/*
 * code_manager.h
 */
#ifndef CODE_MANAGER_H
#define CODE_MANAGER_H


#include "assembler.h"

typedef struct machine_instruction_arguments
{
  char operand[MAX_CODE_ARGS][SYMBOL_MAX_LENGTH+1];
  unsigned int addressing_method_decimal;
  char addressing_method_binary[3];
  char additional_word[BITS_IN_REGISTER];
} instrcution_struct;


typedef struct machine_instruction_first_word_structure
{
  char group[3];
  char opcode[5];
  char source_operand_addressing[3];
  char target_operand_addressing[3];
  char ERA[3];
} code_struct;

enum addressing_method { immediate, direct, destination, direct_register, illegal};

typedef struct addressing_method_info_record
{
  enum addressing_method method;
  char operands [MAX_CODE_ARGS+1][SYMBOL_MAX_LENGTH+1];
} address_method_record;


void code_struct_initialize (code_struct* code_bit_struct);
void concat_first_word_components (char binary_vector[BITS_IN_REGISTER], code_struct *components);
int set_code (char code_image[MAX_OUTPUT_CODE_LINES][BITS_IN_REGISTER+1], unsigned int *IC, char *binary_machine_instruction, unsigned int line_num, unsigned int *error_flag);
int get_instruction_args (char *source_input, instrcution_struct target_args[MAX_CODE_ARGS], int *num_of_args, opcode *op_table, assembly_register *reg_table, unsigned line_num, unsigned int *error_flag);


#endif
