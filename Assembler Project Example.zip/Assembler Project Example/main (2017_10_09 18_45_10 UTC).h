/*
 * main.h
 *
 *  Created on: 20 ���� 2015
 *      Author: chanan
 */

#ifndef MAMAN14_MAIN_H_
#define MAMAN14_MAIN_H_

#define FILE_MAX_NAME 260
#define MAX_FILES 100

int assemble_file (obj_file_struct *obj_record, entry **, external_symbol**, opcode table[NUM_OF_OPCODES], assembly_register reg_table[NUM_OF_REGISTERS]);
int generate_object_file (obj_file_struct file_record, char *file_name);
int generate_entry_file (entry *entry_file_record, char *file_name);
int generate_extern_file (external_symbol *extern_file_record, char *file_name);

const char file_name_suffix[]  = ".as";
const char object_name_suffix[] = ".ob";
const char entry_name_suffix[] = ".ent";
const char extern_name_suffix[] = ".ext";

#endif /* MAMAN14_MAIN_H_ */
