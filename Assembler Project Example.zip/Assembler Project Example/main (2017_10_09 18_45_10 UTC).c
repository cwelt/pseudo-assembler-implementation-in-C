
/**********************************************************************************************************/
/* 2015A - 20465 : Final Project    ***********************************************************************/
/* @authors:   Alex Spayev & Chanan Welt   ****************************************************************/
/* @date 15/03/2015     ***********************************************************************************/
/**********************************************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "main.h"
#include "symbols.h"
#include "assembler.h"
#include "code_manager.h"

int main (int argc, char *argv[])
{
    FILE *fp; /* file pointer */
    obj_file_struct obj_file_record;
    entry *entry_file_record;
    external_symbol *extern_file_record;
    unsigned int file_counter = 0;
    char *argument_name; /* name of current command line argument */
    char file_name[FILE_MAX_NAME];

    const unsigned int suffix_length = strlen(file_name_suffix);
    const unsigned int allowed_length = FILE_MAX_NAME - suffix_length;
    unsigned int arg_name_length;

    opcode opcode_table[NUM_OF_OPCODES];
    assembly_register register_table[NUM_OF_REGISTERS];

    if (argc > MAX_FILES+1)
         fprintf(stderr, "%s: Warning: Maximum files allowed is %d. the remaining files won't be processed.\n", argv[0], MAX_FILES);

    if (argc == 1) /* no arguments (no files) */
    {
        fprintf(stderr, "%s: Error: no files found for the assmebler\n", argv[0]);
        exit (EXIT_FAILURE);
    }

    else /* at least one argument given */
        set_opcode_table(opcode_table);
        set_register_table(register_table);

        while (--argc > 0 && file_counter < MAX_FILES)
        {
            file_counter++;
            argument_name = *++argv;
            arg_name_length = strlen(argument_name);

            if (arg_name_length > allowed_length)
            {
              fprintf(stderr, "%s:Error: File name is too long!\n", argv[0]);
              continue;
            }
            strcpy(file_name, argument_name);
            strcat(file_name, file_name_suffix);

            if ((fp = fopen(file_name, "r")) == NULL)
                fprintf(stderr,"System failure occoured in attempt to open file \"%s\"\n", file_name);
            else
            {
                fprintf(stderr, "======================================================================\n");
                fprintf(stderr, "----------------------------------------------------------------------\n");
                fprintf(stderr, "\t\tCompilation report for file \"%s\":\n", file_name);
                fprintf(stderr, "----------------------------------------------------------------------\n");
                strcpy(obj_file_record.name, file_name);
                obj_file_record.file_ptr = fp;
                assemble_file (&obj_file_record, &entry_file_record, &extern_file_record, opcode_table, register_table);

                /* check if errors occoured during compilation */
                if (obj_file_record.errors == 0)
                { /* if no errors - generate necessary output files */
                  /* (A) Generate Object File */
                  if(generate_object_file (obj_file_record, *argv) == EXIT_SUCCESS)
                    fprintf(stderr, "File %s%s has been successfully generated\n", *argv, object_name_suffix);


                  if (entry_file_record != NULL)
                  { /* (B) Generate Entry File if any entries have been registerd */
                    if(generate_entry_file(entry_file_record, *argv) == EXIT_SUCCESS)
                      fprintf(stderr, "File %s%s has been successfully generated\n", *argv, entry_name_suffix);
                    free_entry_table(entry_file_record); /* release allocated memory back to OS */
                  }

                  if (extern_file_record != NULL)
                  { /* (C) Generate Extern File if any extern declarations have been made */
                    if(generate_extern_file(extern_file_record, *argv) == EXIT_SUCCESS)
                      fprintf(stderr, "File %s%s has been successfully generated\n", *argv, extern_name_suffix);
                    free_extern_table(extern_file_record); /* release allocated memory back to OS */
                  }
                }
                /* clean up I/O file pointers */
                fclose(obj_file_record.file_ptr);
                fflush(NULL);
                fprintf(stderr, "======================================================================\n");
            }
        }
    exit (EXIT_SUCCESS);
}





int generate_object_file (obj_file_struct file_record, char *file_name)
{
  FILE *ofp; /* output file pointer */
  unsigned int current_address = BASE_START;
  char object_file_name[FILE_MAX_NAME];
  int i;

  /* (1) create a name for the object file */
  strcpy(object_file_name, file_name);
  strcat(object_file_name, object_name_suffix);

  /* (2) try to create the object file */
  if((ofp = fopen(object_file_name, "w")) == NULL)
  {
    fprintf(stderr, "Error: System failure while attempting to create file \"%s\"\n", object_file_name);
    return(EXIT_FAILURE);
  }

  /* (3) print title of file */
  fprintf(ofp, "\tBase %d Address \t Base %d machine code\n\n", OBJECT_BASE, OBJECT_BASE);

  /* (4) print instruction and data counters (IC and DC) */
  fprintf(ofp, "\t\t     %30X    %X\n", file_record.IC-1, file_record.DC);

  /* (5) print address list and machine code in hexadecimal base */
  for (i=0; i < file_record.IC; i++)
    fprintf(ofp, "\t %7X \t\t\t %03X\n",current_address++, convert_binary_to_decimal(file_record.code_image[i]));
  for (i=0; i < file_record.DC; i++)
    fprintf(ofp, "\t %7X \t\t\t %03X\n",current_address++, convert_binary_to_decimal(file_record.data_image[i]));

  /* (6) close file and return to caller */
  return (fclose(ofp));
}


int generate_entry_file (entry *entry_file_record, char *file_name)
{
  FILE *ofp; /* output file pointer */
  char entry_file_name[FILE_MAX_NAME];

  /* (1) create a name for the object file */
  strcpy(entry_file_name, file_name);
  strcat(entry_file_name, entry_name_suffix);

  /* (2) try to create the entry file */
  if((ofp = fopen(entry_file_name, "w")) == NULL)
  {
    fprintf(stderr, "Error: System failure while attempting to create file \"%s\"\n", entry_file_name);
    return(EXIT_FAILURE);
  }

  /* (3) print entry symbols list and their addresses as defined in source file */
  while (entry_file_record != NULL)
  {
    fprintf(ofp, "%-30s %X\n", entry_file_record->name, entry_file_record->address_decimal_value);
    entry_file_record = entry_file_record -> next;
  }

  /* (4) close file and return to caller */
  return (fclose(ofp));
}

int generate_extern_file (external_symbol *extern_file_record, char *file_name)
{
  FILE *ofp; /* output file pointer */
  char extern_file_name[FILE_MAX_NAME];

  /* (1) create a name for the object file */
  strcpy(extern_file_name, file_name);
  strcat(extern_file_name, extern_name_suffix);

  /* (2) try to create the extern file */
  if((ofp = fopen(extern_file_name, "w")) == NULL)
  {
    fprintf(stderr, "Error: System failure while attempting to create file \"%s\"\n", extern_file_name);
    return(EXIT_FAILURE);
  }

  /* (3) print extern symbols list used and addresses for future linking and loading */
  while (extern_file_record != NULL)
  {
    fprintf(ofp, "%-30s %X\n", extern_file_record->name, extern_file_record->address_decimal_value);
    extern_file_record = extern_file_record -> next;
  }

  /* (4) close file and return to caller */
  return (fclose(ofp));
}


